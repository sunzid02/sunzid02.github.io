import HomeView from "./app/view/HomeView";

export default function App() {
  return <HomeView />;
}
